package pageObjectRepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import core.Base;
import utilites.WebDriverUtility;

public class HomePageObject extends Base{

	public HomePageObject() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//span[contains(text(),'Currency')]")
	private WebElement Currency;
	
	@FindBy(xpath = "//i[@class='fa fa-phone']")
	private WebElement PhoneNumber;
	
	@FindBy(xpath = "//span[contains(text(),'My Account')]")
	private WebElement MyAccountLogin;
	
	@FindBy(xpath = "//span[contains(text(),'Wish List (0)')]")
	private WebElement WishList;
	
	@FindBy(xpath = "//span[contains(text(),'Shopping Cart')]")
	private WebElement ShoppingCart;
	
	@FindBy(xpath = "//span[contains(text(),'Checkout')]")
	private WebElement CheckOut;
	
	@FindBy(id = "logo")
	private WebElement logo;
	
	@FindBy(id = "cart-total")
	private WebElement cartTotal;
	
	@FindBy(xpath = "//a[text()='Desktops']")
	private WebElement deskTops;
	
	@FindBy(xpath="//a[contains(text(),'Show All Desktops')]")
	private WebElement ShowAllDesktops;
	
	@FindBy(xpath = "//a[text()='Laptops & Notebooks']")
	private WebElement LaptopsAndNotebooks;
	
	@FindBy(xpath = "//a[contains(text(),'Show All Laptops & Notebooks')]")
	private WebElement ShowAllLaptopsAndNotebooks;
	
	@FindBy(xpath = "//a[text()='Components']")
	private WebElement components;
	
	@FindBy(xpath = "//a[contains(text(),'Show All Components')]")
	private WebElement ShowAllComponents;

	
	@FindBy(xpath = "(//a[text()='Tablets'])[1]")
	private WebElement Tablets;
	
	@FindBy(xpath = "//a[contains(text(),'Show All Cameras')]")
	private WebElement ShowAllCameras;
	
	@FindBy(xpath = "//a[text()='Software']")
	private WebElement Software;
	
	@FindBy(xpath ="//a[contains(text(),'Phones & PDAs')]")
	private WebElement PhonesAndPDAs;
	
	@FindBy(xpath = "//a[text()='Cameras']")
	private WebElement Cameras;
	
	@FindBy(xpath = "//a[text()='MP3 Players']")
	private WebElement Mp3Players;
	@FindBy(xpath = "//a[contains(text(),'Show All MP3 Players')]")
	private WebElement ShowAllMp3Players;
	
	@FindBy(id = "slideshow0")
	private WebElement slideshow;
	
	@FindBy(id="search")
	private WebElement search;
	
	@FindBy(xpath = "//i[@class='fa fa-search']")
	private WebElement searchIcon;
	
	@FindBy(xpath = "//img[@title='MacBook']")
	private WebElement MacBookImage;
	
	@FindBy(xpath ="//a[text()='MacBook']")
	private WebElement mackBook;
	
	@FindBy(xpath = "//img[@title='iPhone']")
	private WebElement iPhoneImage;
	
	
	@FindBy(xpath = "//a[text()='iPhone']")
	private WebElement iPhone;
	
	@FindBy(xpath = "//img[@title='Apple Cinema 30\"']")
	private WebElement AppleImage;
	
	@FindBy(xpath="//a[text()='Apple Cinema 30\"']")
	private WebElement Apple;
	
	@FindBy(xpath = "//img[@title='Canon EOS 5D']")
	private WebElement CanonImage;
	
	@FindBy(xpath = "//a[text()='Canon EOS 5D']")
	private WebElement Canon;
	
	@FindBy(id = "carousel0")
	private WebElement Carousel;
	
	@FindBy(xpath = "//h5[contains(text(),'Information')]")
	private WebElement Information;
	
	@FindBy(linkText ="About Us")
	private WebElement AboutUs;
	
	@FindBy(linkText = "Delivery Information")
	private WebElement DeliveryInfo;
	
	@FindBy(xpath = "//a[contains(text(),'Privacy Policy')]")
	private WebElement PrivacyPolicy;
	
	@FindBy(linkText = "Terms & Conditions")
	private WebElement TermsAndConditions;
	
	@FindBy(xpath = "//h5[contains(text(),'Customer Service')]")
	private WebElement CustomerService;
	
	@FindBy(xpath ="//a[contains(text(),'Contact Us')]" )
	private WebElement ContactUs;
	
	@FindBy(linkText = "Returns")
	private WebElement Returns;
	
	@FindBy(linkText = "Site Map")
	private WebElement SiteMap;
	
	@FindBy(xpath = "//h5[text() ='Extras']")
	private WebElement Extras;
	
	@FindBy(linkText = "Brands")
	private WebElement Brands;
	
	@FindBy(xpath = "//a[contains(text(),'Gift Certificates')]")
	private WebElement GiftCertificates;
	
	@FindBy(linkText="Affiliate")
	private WebElement Affiliate;
	
	@FindBy(linkText = "Specials")
	private WebElement Specials;
	
	@FindBy(xpath = "//h5[contains(text(),'My Account')]")
	private WebElement myAccountHeader;
	
	@FindBy(xpath = "//a[contains(text(),'My Account')]")
	private WebElement MyAccount;
	
	@FindBy(xpath = "//a[contains(text(),'Order History')]")
	private WebElement OrderHistory;
	
	@FindBy(xpath = "//a[contains(text(),'Wish List')]")
	private WebElement wishListBottomFooter;
	
	@FindBy(xpath = "//a[contains(text(),'Newsletter')]")
	private WebElement Newsletter;
	
	
	
	
	public void clickOnSearchBar() {
		WebDriverUtility.clickOnElement(search);
	}
	
	
}
