package pageObjectRepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import core.Base;

public class DesktopsPageObject extends Base {
	
	public DesktopsPageObject() {
		PageFactory.initElements(driver, this);	
		
	}
	@FindBy(xpath="//a[contains(text(),'Show All Desktops')]")
	private WebElement ShowAllDesktops;
	
	
	@FindBy(xpath = "//img[@class='img-thumbnail']")
	private WebElement imageDesktops;
	
	@FindBy(xpath = "//a[contains(text(),'Desktops (13)')]")
	private WebElement DeskTopTotal;
	
	@FindBy(xpath = "//a[@class='list-group-item'] [1]")
	private WebElement PCListItem;
	
	@FindBy(xpath = "//a[contains(text(),'- Mac (1)')]")
	private WebElement MacListItem;
	
	@FindBy(xpath = "//a[contains(text(),'Laptops & Notebooks (5)')]")
	private WebElement LaptopsAndNoteBooksItemList;
	
	@FindBy(xpath = "//a[contains(text(),'Components (2)')]")
	private WebElement ComponentsListItem;
	
	@FindBy(xpath = "//a[contains(text(),'Tablets (1)')]")
	private WebElement TabletListItem;
	
	@FindBy(xpath = "//a[contains(text(),'Software (0)')]")
	private WebElement SoftwareListItem;
	
	@FindBy(xpath = "//a[contains(text(),'Phones & PDAs (3)')]")
	private WebElement PhonesAndPDASListItem;
	
	@FindBy(xpath = "//a[contains(text(),'Cameras (2)')]")
	private WebElement CamerasListItem;
	
	@FindBy(xpath = "//a[contains(text(),'MP3 Players (4)')]")
	private WebElement Mp3PlayersListItem;
	
	@FindBy(xpath = "//img[@alt='HP Banner']")
	private WebElement HpBanner;
	
	@FindBy(id = "list-view")
	private WebElement listView;
	
	@FindBy(id = "grid-view")
	private WebElement gridView;
	
	@FindBy(xpath = "//a[@id='compare-total']")
	private WebElement compareTotal;
	
	@FindBy(id = "input-sort")
	private WebElement inputSort;
	
	@FindBy(id = "input-limit")
	private WebElement inputLimit;
	
	@FindBy(xpath = "//img[@title='Apple Cinema 30\"']")
	private WebElement AppleCinemaImage;
	
	@FindBy(xpath = "//a[contains(text(),'Apple Cinema 30\"')]")
	private WebElement AppleCinema;
	
	@FindBy(xpath ="(//span[text()='Add to Cart'])[1]")
	private WebElement AppleAddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[2]")
	private WebElement AppleWishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[1]")
	private WebElement AppleCompareProduct;
	
	@FindBy(xpath ="(//a[text()='PC (0)'])[1]" )
	private WebElement PCSearch;
	
	@FindBy(xpath = "//img[@title='Canon EOS 5D']")
	private WebElement CanonEOS5DImage;
	
	@FindBy(xpath ="//a[contains(text(),'Canon EOS 5D')]" )
	private WebElement CanonEOS5D;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[2]")
	private WebElement CanonEOSAddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[3]")
	private WebElement CanonEOSWishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[2]")
	private WebElement CanonEOSCompare;
	
	@FindBy(xpath = "//img[@title='HP LP3065']")
	private WebElement HPLP36065Image;
	
	@FindBy(xpath = "//a[contains(text(),'HP LP3065')]")
	private WebElement HPLP3065;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[3]")
	private WebElement HPLP3065AddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[4]")
	private WebElement HPLP3065WishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[3]")
	private WebElement HPLP3065Compare;
	
	@FindBy(xpath = "//img[@title='HTC Touch HD']")
	private WebElement HTCTouchHDImage;
	
	@FindBy(xpath = "//a[contains(text(),'HTC Touch HD')]")
	private WebElement HTCTouchHD;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[4]")
	private WebElement HTCTouchAddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[5]")
	private WebElement HTCWishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[4]")
	private WebElement HTCCompare;
	
	@FindBy(xpath = "//img[@title='iPod Classic']")
	private WebElement iPodClassicImage;
	
	@FindBy(xpath = "//a[contains(text(),'iPod Classic')]")
	private WebElement iPodClassic;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[6]")
	private WebElement iPodAddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[7]")
	private WebElement iPodWishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[6]")
	private WebElement iPodCompare;
	
	@FindBy(xpath = "//img[@title='MacBook']")
	private WebElement MacBookImage;
	
	@FindBy(linkText = "MacBook")
	private WebElement MacBook;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[7]")
	private WebElement MacBookAddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[8]")
	private WebElement MacBookWishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[7]")
	private WebElement MacBookCompare;
	
	@FindBy(xpath = "//img[@title='MacBook Air']")
	private WebElement MacBookAirImage;
	
	@FindBy(xpath = "//a[contains(text(),'MacBook Air')]")
	private WebElement MacBookAir;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[8]")
	private WebElement MacBookAirAddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[9]")
	private WebElement MacBookAirWishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[8]")
	private WebElement MacBookAirCompare;
	
	@FindBy(xpath = "//img[@title='Palm Treo Pro']")
	private WebElement PalmTreoProImage;
	
	@FindBy(xpath = "//a[contains(text(),'Palm Treo Pro')]")
	private WebElement PalmTreoPro;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[9]")
	private WebElement PalmTreoAddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[10]")
	private WebElement PalmTreoWishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[9]")
	private WebElement PalmTreoCompare;
	
	@FindBy(xpath = "//img[@title='Product 8']")
	private WebElement Product8Image;
	
	@FindBy(xpath = "//a[contains(text(),'Product 8')]")
	private WebElement Product8;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[10]")
	private WebElement Product8AddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[11]")
	private WebElement Product8WishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[10]")
	private WebElement Product8Compre;
	
	@FindBy(xpath = "//img[@title='Samsung SyncMaster 941BW']")
	private WebElement SamsungSyncMasterImage;
	
	@FindBy(xpath = "//a[contains(text(),'Samsung SyncMaster 941BW')]")
	private WebElement SamsungSyncMaster;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[11]")
	private WebElement SamsungAddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[12]")
	private WebElement SamsungWishList;
	
	@FindBy(xpath ="(//i[@class='fa fa-exchange'])[11]" )
	private WebElement SamsungCompare;
	
	@FindBy(xpath = "//img[@title='Sony VAIO']")
	private WebElement SonyVaioImage;
	
	@FindBy(xpath = "//a[contains(text(),'Sony VAIO')]")
	private WebElement SonyVaio;
	
	@FindBy(xpath = "(//span[text()='Add to Cart'])[12]")
	private WebElement SonyAddToCart;
	
	@FindBy(xpath = "(//i[@class='fa fa-heart'])[11]")
	private WebElement SonyWishList;
	
	@FindBy(xpath = "(//i[@class='fa fa-exchange'])[12]")
	private WebElement SonyCompare;
	
	
	@FindBy(xpath = "//a[contains(text(),'Wish List')]")
	private WebElement wishListBottomFooter;
	
	

}

